package it.contrader.service;

import java.util.List;

import it.contrader.converter.Converter;
import it.contrader.dao.DAO;
import it.contrader.dto.ParametersDTO;
import it.contrader.model.Parameters;


public abstract class AbstractServiceParameters implements Service<ParametersDTO> {
	
	
	
	DAO<Parameters> dao ;
	Converter<Parameters,ParametersDTO> converter ;
	
	
    public List<ParametersDTO> getAll(){
    	
		return converter.toDTOList(dao.getAll());
    	
    }
	
	public ParametersDTO read(int id){
		return converter.toDTO(dao.read(id));
		
	}
	
	public boolean insert(ParametersDTO dto){
		return dao.insert(converter.toEntity(dto));
		
	}
	
	public boolean update(ParametersDTO dto){
		return dao.update(converter.toEntity(dto));
		
	}
	
	public boolean delete(int id){
		
		return dao.delete(id);
		
	}
	
	public void efface(){
		
	}
	
	public void effacer(String usertype){
		
	}
	
	public int returnBestPlayerLine(){
		return 0;
		
	}

}
