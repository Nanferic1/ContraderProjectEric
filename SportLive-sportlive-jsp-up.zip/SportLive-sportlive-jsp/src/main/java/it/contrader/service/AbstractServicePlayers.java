package it.contrader.service;

import java.util.List;

import it.contrader.converter.Converter;
import it.contrader.dao.DAO;
import it.contrader.dto.PlayersDTO;
import it.contrader.model.Players;

@SuppressWarnings("hiding")
public class AbstractServicePlayers<Players,PlayersDTO> implements Service<PlayersDTO> {
	
	DAO<Players> dao ;
	Converter<Players,PlayersDTO> converter;

	@Override
	public List<PlayersDTO> getAll() {
		return converter.toDTOList(dao.getAll()) ;
	}

	@Override
	public PlayersDTO read(int id) {
		return converter.toDTO(dao.read(id));
	}

	@Override
	public boolean insert(PlayersDTO dto) {
		
		return dao.insert(converter.toEntity(dto));
	}

	@Override
	public boolean update(PlayersDTO dto) {
		
		return dao.update(converter.toEntity(dto));
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return dao.delete(id);
	}

	@Override
	public void efface() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void effacer(String usertype) {
		dao.cancella(usertype);
		
	}

	@Override
	public int Tipo_di_utente(int id) {
		// TODO Auto-generated method stub
		return 0;
	}
	public int returnBestPlayerLine(){
		
		return dao.RestituireFirstId();
		
	}

}
