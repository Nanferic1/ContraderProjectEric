package it.contrader.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.contrader.dto.PlayersDTO;
import it.contrader.dto.UserDTO;
import it.contrader.service.PlayersService;
import it.contrader.service.Service;
import it.contrader.service.UserService;

/**
 * Servlet implementation class BestPlayer
 */
public class BestPlayer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BestPlayer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    public void updateList(HttpServletRequest request) {
		Service<PlayersDTO> service = new PlayersService();
		
		List<PlayersDTO> listDTO = service.getAll(); // metodo do lavoro
		request.setAttribute("list", listDTO);
	}
    
    public void updateListBestPlayer(HttpServletRequest request) {
		Service<PlayersDTO> service = new PlayersService();
		   if(service.returnBestPlayerLine()>0){
		   String listDTO = String.valueOf(service.returnBestPlayerLine()); // metodo do lavoro
		request.setAttribute("list", listDTO);
		   }
		   else{
		   request.setAttribute("list", "Null best player at this time"); 
		   }
	}
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String mode = request.getParameter("mode");
         
	        switch (mode.toLowerCase()) { 

	 		case "bestplayer":
	 			updateListBestPlayer(request);
	 			getServletContext().getRequestDispatcher("/user/BestPlayer.jsp").forward(request, response);
	 			break; 
	         }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
