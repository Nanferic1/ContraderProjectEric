package it.contrader.servlets;

public class CheckUtente {

	private String utente = null;
	
 public CheckUtente(String utente){
	   this.utente=utente;
 }
 
 public String getUtente(){
	 return this.utente;
	 
 }
	

}
