package it.contrader.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.contrader.dto.PlayersDTO;
import it.contrader.dto.UserDTO;
import it.contrader.service.PlayersService;
import it.contrader.service.Service;
import it.contrader.service.UserService;

/**
 * Servlet implementation class CreateServletPlayers
 */
public class CreateServletPlayers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateServletPlayers() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public boolean checkNumberFormat(String string){
		  boolean var=false;
		  
		  try{
			Integer.parseInt(string);
			var=true;
		  }
		  catch(NumberFormatException e){
			  
			 var=false; 
		  }
		return var;
	}

 	public void updateList(HttpServletRequest request) {
		Service<PlayersDTO> service = new PlayersService();
		
		List<PlayersDTO> listDTO = service.getAll();
		request.setAttribute("list", listDTO);
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
     
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mode =request.getParameter("mode").toString();
	 switch(mode.toUpperCase()){
	 case "CREATEPLAYER":
		    updateList(request) ;
			getServletContext().getRequestDispatcher("/user/createPlayers.jsp").forward(request, response);	 
	break;	
	
	 case "BOXUPDATE":
		 updateList(request) ;
			getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 
		 break;
		
	 case "BOXDELETE":
		 int id1 = Integer.parseInt(request.getParameter("id"));
	    	Service<PlayersDTO> service2 = new PlayersService();
	    	    if(service2.delete(id1)){ 
	    	    request.setAttribute("list1", " Operazione di delete eseguita con successo!!!");	 	 
	            updateList(request) ;
				getServletContext().getRequestDispatcher("/user/createPlayers.jsp").forward(request, response);	 	 	 
	    	     }
	    	     request.setAttribute("list1", " Operazione di delete non eseguita!!!");	 	 
	             updateList(request) ;
	 			getServletContext().getRequestDispatcher("/user/createPlayers.jsp").forward(request, response);	 	 	 
		 
		 break;
		 
     case "UPDATEPLAYER":
    	 
    	    String Idplayer =(String)request.getParameter("Idplayer");
			String Nickname =(String) request.getParameter("Nickname");
			String Password =(String) request.getParameter("Password");
			String Playertype =(String) request.getParameter("Playertype");
			String Score =(String) request.getParameter("Score");
			if((Idplayer !="") && (Nickname !="") 
				 	  && (Password !="") && (Playertype !="") && (Score !="")){
				
				if(!(checkNumberFormat(Idplayer)) || 
				 	    !(checkNumberFormat(Score))){
					request.setAttribute("list1", "Problemi nei campi Idplayer o Score !!!");
					 updateList(request) ;
						getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 	
				}
				else{
				
				int idplayer =Integer.valueOf(Idplayer);
				String nickname = Nickname ;
				String password = Password;
				String playertype = Playertype;
				int score = Integer.valueOf(Score);
				
		PlayersDTO playerdto = new PlayersDTO(idplayer,nickname,password,playertype,score);		
		Service<PlayersDTO> service = new PlayersService();
		        if(service.update(playerdto)){
		        	request.setAttribute("list1", "Update avvenuto con successo !!!");
					 updateList(request) ;
						getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 		
		        }
		        else{
		        	request.setAttribute("list1", "Operazione non ha avuto successo,riprovare !!!");
					 updateList(request) ;
						getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 			
		        }
		
				
					
				}
				
			}
			else{
				request.setAttribute("list1", "Almeno uno campo � vuoto !!!");
				 updateList(request) ;
					getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 
			}
				 	 
			
			
    	 
    	     updateList(request) ;
			getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 	 
		 
		 break;	 
		 
     case "DELETEPLAYER":
    	int id = Integer.parseInt(request.getParameter("id"));
    	Service<PlayersDTO> service1 = new PlayersService();
    	    if(service1.delete(id)){ 
    	    request.setAttribute("list1", " Operazione di delete eseguita con successo!!!");	 	 
            updateList(request) ;
			getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 	 
    	     }
    	     request.setAttribute("list1", " Operazione di delete non eseguita!!!");	 	 
             updateList(request) ;
 			getServletContext().getRequestDispatcher("/user/UpdatePlayerMode.jsp").forward(request, response);	 	 	 
    	 break;
		 
	 }
	 
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
