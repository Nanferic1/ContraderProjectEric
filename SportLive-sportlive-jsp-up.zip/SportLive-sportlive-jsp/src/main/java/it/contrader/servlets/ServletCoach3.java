package it.contrader.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.contrader.dto.DeviceDTO;
import it.contrader.dto.ParametersDTO;
import it.contrader.dto.PlayersDTO;
import it.contrader.dto.UserDTO;
import it.contrader.service.DeviceService;
import it.contrader.service.ParametersService;
import it.contrader.service.PlayersService;
import it.contrader.service.Service;

/**
 * Servlet implementation class ServletCoach3
 */
public class ServletCoach3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Service<ParametersDTO> service ;  
	    String Idplayer ;
		String Data ;
		String Age ;
		String Height ;
		String Weight ;
		String Gol ;
		String Gp ;
		String Mp ;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCoach3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void updateList(HttpServletRequest request) {
		Service<ParametersDTO> service = new ParametersService();
		
		List<ParametersDTO> listDTO = service.getAll();
		request.setAttribute("list", listDTO);
	} 
	
	public void updateListPlayers(HttpServletRequest request) {
		Service<PlayersDTO> service = new PlayersService();
		
		List<PlayersDTO> listDTO = service.getAll();
		request.setAttribute("list", listDTO);
	}
	
	public boolean checkNumberFormat(String string){
		  boolean var=false;
		  
		  try{
			Integer.parseInt(string);
			var=true;
		  }
		  catch(NumberFormatException e){
			  
			 var=false; 
		  }
		return var;
	}
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 List<ParametersDTO> dto2 ;
         service = new ParametersService();
         dto2 =  service.getAll();
         String mode = request.getParameter("mode");
         
        switch (mode.toUpperCase()) { 

 		case "USERLIST":
 			updateList(request);
 			getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);
 			break; 
 		case "INSERTSTATISTICS":
 			 Data =(String)request.getParameter("Data");
 			 Age =(String) request.getParameter("Age");
 			 Height =(String) request.getParameter("Height");
 			 Weight =(String) request.getParameter("Weight");
 			 Gol =(String) request.getParameter("Gol");
 			 Gp =(String) request.getParameter("Gp");
 			 Mp =(String) request.getParameter("Mp");
 			 
 	if((Data !="") && (Age !="") 
 	  && (Height !="") && (Weight !="") && (Gol !="")
 	  && (Gp !="") && (Mp !="")
 			
 			){
 	
 	if(checkNumberFormat(Data) && 
 	    checkNumberFormat(Age)	&&   checkNumberFormat(Height)  &&
 	    checkNumberFormat(Weight)	&&  checkNumberFormat(Gol)  &&
 	    checkNumberFormat(Gp)	&&   checkNumberFormat(Mp)  	   
 			){
 	// si salve nella tabella 
 		
 		int data = Integer.parseInt(Data);
 		int age = Integer.parseInt(Age);
 		int height =Integer.parseInt(Height);
 		int weight = Integer.parseInt(Weight);
 		int gol = Integer.parseInt(Gol);
 		int gp = Integer.parseInt(Gp);
 		int mp = Integer.parseInt(Mp);
 		ParametersDTO parametersdto=new ParametersDTO(0,data,age,height,weight,gol,gp,mp);
 		Service<ParametersDTO> service = new ParametersService();
 		             service.insert(parametersdto);
 		request.setAttribute("list1", " Operazione eseguita con successo!!!");	
 		updateList(request);
	    getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);	
 	}
 	
 	else{
 		request.setAttribute("list1", " Almeno uno campo non possiede un number intero!!!");
 		updateList(request);
	    getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);
 	}
 	
 	
 	}
 	else{
 		request.setAttribute("list1", "Almeno uno campo � vuoto !!!");
 		updateList(request);
		getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);
 	} 
 			
 			
 			
 			
 			//request.setAttribute("list", dto2);
 			
 			break;
        
        case "CREATE PLAYER":
        	
        	String nickname =request.getParameter("nickname").toString();
        	String password =request.getParameter("password").toString();
        	String playertype = request.getParameter("playertype").toString();
        	// crea
        	if(nickname.equals("player") && password.equals("player") && playertype.equals("player")){
        		PlayersDTO playerdto = new PlayersDTO(0,nickname,password,playertype, 0);
            	Service<PlayersDTO> service1 = new PlayersService();
            	                   //service1.insert(playerdto);
            	
            	if(!service1.insert(playerdto)){
            		request.setAttribute("list1", "Il player non � stato registrato !!!");	
            		updateListPlayers(request);
                	getServletContext().getRequestDispatcher("/user/createPlayers.jsp").forward(request, response);	
            	}
            	else{
            		request.setAttribute("list1", "Registrazione avvenuta con successo !!!");		
            	updateListPlayers(request);
            	getServletContext().getRequestDispatcher("/user/createPlayers.jsp").forward(request, response);	
            	}
       
        	}
        	else{
        		
        		request.setAttribute("list1", "Errore nel inserimento !!!");	
        		updateListPlayers(request);
            	getServletContext().getRequestDispatcher("/user/createPlayers.jsp").forward(request, response);	
        	
        	}
        	
        	break;
        	
        case "ENTRAINUPDATE":
        	 updateList(request) ;
				getServletContext().getRequestDispatcher("/user/Parametersupdate.jsp").forward(request, response);	 	 	 	
        	
        break;
        
        case "UPDATE":
        	String Idplayer1 =(String)request.getParameter("PlayerId");
        	String Data1 =(String)request.getParameter("Data");
 			String Age1 =(String) request.getParameter("Age");
 			String Height1 =(String) request.getParameter("Height");
 			String Weight1 =(String) request.getParameter("Weight");
 		    String Gol1 =(String) request.getParameter("Gol");
 			String Gp1 =(String) request.getParameter("Gp");
 			String Mp1 =(String) request.getParameter("Mp");
 			 
 	if((Data1 !="") && (Age1 !="") && (Idplayer1 !="") 
 	  && (Height1 !="") && (Weight1 !="") && (Gol1 !="")
 	  && (Gp1 !="") && (Mp1 !="")
 			
 			){
 	
 	if( checkNumberFormat(Idplayer1) && checkNumberFormat(Data1) && 
 	    checkNumberFormat(Age1)	&&   checkNumberFormat(Height1)  &&
 	    checkNumberFormat(Weight1)	&&  checkNumberFormat(Gol1)  &&
 	    checkNumberFormat(Gp1)	&&   checkNumberFormat(Mp1)  	   
 			){
 	// si salve nella tabella 
 		int idplayer = Integer.parseInt(Idplayer1);
 		int data = Integer.parseInt(Data1);
 		int age = Integer.parseInt(Age1);
 		int height =Integer.parseInt(Height1);
 		int weight = Integer.parseInt(Weight1);
 		int gol = Integer.parseInt(Gol1);
 		int gp = Integer.parseInt(Gp1);
 		int mp = Integer.parseInt(Mp1);
 		ParametersDTO parametersdto=new ParametersDTO(idplayer,data,age,height,weight,gol,gp,mp);
 		Service<ParametersDTO> service = new ParametersService();
 		    if(service.update(parametersdto)){
 		request.setAttribute("list1", " Operazione eseguita con successo!!!");	
 		updateList(request);
	    getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);
 		    }
 		    else{ 
 		   request.setAttribute("list1", " Operazione non eseguita con successo!!!");	
 	 		updateList(request);
 		    getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);
 		       }
 		    }
 	
 	else{
 		request.setAttribute("list1", " Almeno uno campo non possiede un number intero!!!");
 		updateList(request);
	    getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);
 	}
 	
 	
 	}
 	else{
 		request.setAttribute("list1", "Almeno uno campo � vuoto !!!");
 		updateList(request);
		getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);
 	} 
 				
        	
        	break;
       
        case "DELETE":
        	 int id1 = Integer.parseInt(request.getParameter("id"));
 	    	Service<ParametersDTO> service2 = new ParametersService();
 	    	    if(service2.delete(id1)){ 
 	    	    request.setAttribute("list1", " Operazione di delete eseguita con successo!!!");	 	 
 	            updateList(request) ;
 				getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);	 	 	 
 	    	     }
 	    	     request.setAttribute("list1", " Operazione di delete non eseguita!!!");	 	 
 	             updateList(request) ;
 	 			getServletContext().getRequestDispatcher("/user/Parametersmanager.jsp").forward(request, response);	 	 	 	
        	
            break;
        
        }
         
      /*   PrintWriter out = response.getWriter();
                     
        if(dto2==null){
        	out.print("Niente");
        }
        else{
        	out.print("Ok: ");
       for(int i=0;i<dto2.size();i++){
    	  out.print(dto2.get(i)+"  "); 
       }
        } */
         
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

   

}
