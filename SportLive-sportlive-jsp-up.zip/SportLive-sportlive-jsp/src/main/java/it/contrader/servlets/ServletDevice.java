package it.contrader.servlets;

import java.util.List;



import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.contrader.dto.DeviceDTO;
import it.contrader.service.*;
//import it.contrader.service.Service;
//import it.contrader.service.UserService;

/*
 * Per dettagli vedi Guida sez Servlet
 */
public class ServletDevice extends HttpServlet {
	private static final long serialVersionUID = 1L;
    LoginService check = new LoginService();
    Service<DeviceDTO> service ;
	public ServletDevice() {
	}
	
 	public void updateList(HttpServletRequest request) {
		Service<DeviceDTO> service = new DeviceService();
		
		List<DeviceDTO> listDTO = service.getAll();
		request.setAttribute("listdevice", listDTO);
	} 

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 	Service<DeviceDTO> service = new DeviceService();
		String mode = request.getParameter("mode");
		DeviceDTO dto;
	    DeviceDTO user;
	    String usertypeCheck;
		int id;
		boolean ans;

		switch (mode.toUpperCase()) { 

		case "USERLIST":
			updateList(request);
			getServletContext().getRequestDispatcher("/user/Devicemanager.jsp").forward(request, response);
			break; 

	/*	case "READ":
			id = Integer.parseInt(request.getParameter("id"));
			dto = service.read(id);
			request.setAttribute("dto", dto);
			
			if (request.getParameter("update") == null) {
				 getServletContext().getRequestDispatcher("/user/readuser.jsp").forward(request, response);
				
			}
			
			else getServletContext().getRequestDispatcher("/user/updateuser.jsp").forward(request, response);
			
			break;

		case "INSERT":
			String username = request.getParameter("username").toString().toLowerCase();
			String password = request.getParameter("password").toString().toLowerCase();
			String usertype = request.getParameter("usertype").toString().toLowerCase();
			     user = check.login(username, password);
			     usertypeCheck = user.getUsertype().toUpperCase();
			     String list1=null;
			     CheckUtente u=null;
			 switch(usertypeCheck){
			 case "DEVICE":
				   u = new CheckUtente(usertypeCheck);
				  list1=u.getUtente(); // Da usare per la stampa piu tardi
				  updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck3.jsp").forward(request, response);
				  break;
			 case "PARAMETERS":
				   u = new CheckUtente(usertypeCheck);
				  list1=u.getUtente(); // Da usare per la stampa piu tardi
				  updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck4.jsp").forward(request, response);
				 break;  
			 case "ADMIN":
				  u = new CheckUtente(usertypeCheck);
				  list1=u.getUtente(); // Da usare per la stampa piu tardi
				  updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck1.jsp").forward(request, response);
				 break;	
			 case "COACH":
				   u = new CheckUtente(usertypeCheck);
				  list1=u.getUtente(); // Da usare per la stampa piu tardi
				  updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck2.jsp").forward(request, response);
				 break;  
			 case "UTENTENONRICONOSCIUTO": 
				 updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagererror.jsp").forward(request, response);
				break; 
			 case "COACH_NON":
				 updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck2.jsp").forward(request, response);	 
				break; 
			 case "ADMIN_NON":
				 updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck1.jsp").forward(request, response);	 
					break; 
			 case "DEVICE_NON":
				 updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck3.jsp").forward(request, response);	 
					break; 
			 case "PARAMETERS_NON":
				 updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck3.jsp").forward(request, response);	  
					break; 	
					
			 case "INSERISCI":
				 
				 if( ((usertype.equals("device") && username.equals("device") && password.equals("device"))) || 
					 ((usertype.equals("parameters") && username.equals("parameters") && password.equals("parameters"))) || 
					 ((usertype.equals("admin") && username.equals("admin") && password.equals("admin"))) || 
					 ((usertype.equals("coach") && username.equals("coach") && password.equals("coach"))) 	 
						 ){
					 dto = new UserDTO (username,password,usertype);
						ans = service.insert(dto);
						request.setAttribute("ans", ans);
						updateList(request);
						getServletContext().getRequestDispatcher("/user/usermanager.jsp").forward(request, response); 
				 }
				 else{ 
				  
				 
				 updateList(request);
				 getServletContext().getRequestDispatcher("/user/usermanagercheck5.jsp").forward(request, response);
				 }
				break;
				 
			 }
			
			  
		     
		     
		  break;	
		     	
		case "UPDATE":
			username = request.getParameter("username");
			password = request.getParameter("password");
			usertype = request.getParameter("usertype");
			id = Integer.parseInt(request.getParameter("id"));
			dto = new UserDTO (id,username, password, usertype);
			ans = service.update(dto);
			updateList(request);
			getServletContext().getRequestDispatcher("/user/usermanager.jsp").forward(request, response);
			break;

		case "DELETE":
			id = Integer.parseInt(request.getParameter("id"));
			String usertype1= new String();
			Service<UserDTO> service1 = new UserService();
			UserDTO dto1 = service1.read(id);
			usertype1 = dto1.getUsertype();
		    if(usertype1.equals("parameters")){
		    	 service.effacer("PARAMETERS");
		    	}
		    if(usertype1.equals("device")){
		    	 service.effacer("DEVICE");
		    	}
		    
			ans = service.delete(id);
			request.setAttribute("ans", ans);
			updateList(request);
			getServletContext().getRequestDispatcher("/user/usermanager.jsp").forward(request, response);
			break;*/
		     
		}
	}
}