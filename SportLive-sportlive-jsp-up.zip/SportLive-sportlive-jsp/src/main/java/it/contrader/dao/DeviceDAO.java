package it.contrader.dao;

import java.sql.*;

import java.util.ArrayList;
import java.util.List;
import it.contrader.utils.ConnectionSingleton;
import it.contrader.model.Device;

public class DeviceDAO implements DAO<Device> {
	
	private final String QUERY_ALL = "SELECT * FROM tabledevice";
	private final String QUERY_ALLPLAYER = "SELECT * FROM tableplayers";
	private final String QUERY_CREATE = "INSERT INTO tabledevice (heartbeat, pressure, breath) VALUES (?,?,?)";
	private final String QUERY_READ = "SELECT * FROM tabledevice WHERE id=?";
	private final String QUERY_UPDATE = "UPDATE tabledevice SET id=?,heartbeat=?, pressure=?, breath=? WHERE id=?";
	private final String QUERY_DELETE = "DELETE FROM tabledevice WHERE id=?";

	public DeviceDAO() {

	}
	
	public List<Device> getAll() {
		List<Device> devicesList = new ArrayList<>();
		Connection connection = ConnectionSingleton.getInstance();
		try {
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery(QUERY_ALL);
			Device device;
			while (resultSet.next()) {
				int idplayer = resultSet.getInt("id");
				int heartbeat = resultSet.getInt("heartbeat");
				int pressure = resultSet.getInt("pressure");
				int breath = resultSet.getInt("breath");
				device = new Device(heartbeat, pressure, breath);
				device.setIdplayer(idplayer);
				devicesList.add(device);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return devicesList;
	}

	

	public boolean insert(Device deviceToInsert) {
		Connection connection = ConnectionSingleton.getInstance();
		try {	
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_CREATE);
			preparedStatement.setInt(1, deviceToInsert.getHeartbeat());
			preparedStatement.setInt(2, deviceToInsert.getPressure());
			preparedStatement.setInt(3, deviceToInsert.getBreath());
			preparedStatement.execute();
			return true;
		} catch (SQLException e) {
			return false;
		}

	}
	
	public Device read(int deviceIdplayer) {
		Connection connection = ConnectionSingleton.getInstance();
		try {


			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_READ);
			preparedStatement.setInt(1, deviceIdplayer);
			ResultSet resultSet = preparedStatement.executeQuery();
			resultSet.next();
			int heartbeat, pressure, breath;

			heartbeat = resultSet.getInt("heartbeat");
			pressure = resultSet.getInt("pressure");
			breath = resultSet.getInt("breath");
			Device device = new Device(heartbeat, pressure, breath);
			device.setIdplayer(resultSet.getInt("id"));
			
			return device;
		} catch (SQLException e) {
			return null;
		}

	}

	public boolean update(Device deviceToUpdate) {
		Connection connection = ConnectionSingleton.getInstance();
         boolean risposta=false;
		if (deviceToUpdate.getIdplayer() == 0){
			risposta = false;
		}
		else {
			
		
		Device deviceRead = read(deviceToUpdate.getIdplayer());
		if(deviceRead==null){
			risposta= false;	
		}
		else{
		
		//if (!deviceRead.equals(deviceToUpdate)) {
			
			
			try {
			 /*	if (deviceToUpdate.getHeartbeat() == 0) {
					deviceToUpdate.setHeartbeat(deviceRead.getHeartbeat());
				}

				if (deviceToUpdate.getPressure() == 0) {
					deviceToUpdate.setPressure(deviceRead.getPressure());
				}

				if (deviceToUpdate.getBreath() == 0) {
					deviceToUpdate.setBreath(deviceRead.getBreath());
				}*/

				PreparedStatement preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY_UPDATE);
				preparedStatement.setInt(1, deviceToUpdate.getIdplayer());
				preparedStatement.setInt(2, deviceToUpdate.getHeartbeat());
				preparedStatement.setInt(3, deviceToUpdate.getPressure());
				preparedStatement.setInt(4, deviceToUpdate.getBreath());
				preparedStatement.setInt(5, deviceToUpdate.getIdplayer());
				int a = preparedStatement.executeUpdate();
				if (a > 0)
					return true;
				else
					return false; 

			} catch (SQLException e) {
				risposta= false;
			}  
			
			
		} 
		}

		return risposta;

	}

	public boolean delete(int idplayer) {
		Connection connection = ConnectionSingleton.getInstance();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_DELETE);
			preparedStatement.setInt(1, idplayer);
			int n = preparedStatement.executeUpdate();
			if (n != 0)
				return true;

		} catch (SQLException e) {
		}
		return false;
	}

	@Override
	public void Cancella() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int RestituireFirstId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void cancella(String usertype) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int WorkTypeUtente(int id) {
		// TODO Auto-generated method stub
		return 0;
	}


}

	
	