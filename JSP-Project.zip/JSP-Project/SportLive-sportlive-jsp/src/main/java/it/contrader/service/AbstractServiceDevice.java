package it.contrader.service;

import java.util.List;

import it.contrader.converter.Converter;

import it.contrader.dao.DAO;

//import it.contrader.dto.DeviceDTO;

@SuppressWarnings("hiding")
public abstract class AbstractServiceDevice<Device,DeviceDTO> implements Service<DeviceDTO> {

	DAO<Device> daoService ;
	Converter<Device,DeviceDTO> deviceConverter ;
	
     public List<DeviceDTO> getAll(){
    	 
   return deviceConverter.toDTOList(daoService.getAll());
    	 
     }
	
	public DeviceDTO read(int id){
		
		return deviceConverter.toDTO(daoService.read(id));
		
	}
	
	public boolean insert(DeviceDTO dto){
		return daoService.insert(deviceConverter.toEntity(dto));
		
	}
	
	public boolean update(DeviceDTO dto){
		
		return daoService.update(deviceConverter.toEntity(dto));
		
	}
	
	public boolean delete(int id){
		return daoService.delete(id);
		
	}
	
	public void efface(){
		
	}
	
	public void effacer(String usertype){
		
	}
	
	public int Tipo_di_utente(int id){
		
		return id;
		
	}

	public int returnBestPlayerLine(){
		return 0;
		
	}
}
