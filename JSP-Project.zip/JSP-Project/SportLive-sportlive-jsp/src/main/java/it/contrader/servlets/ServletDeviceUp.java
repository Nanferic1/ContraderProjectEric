package it.contrader.servlets;

import java.util.List;



import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.contrader.dto.DeviceDTO;
import it.contrader.dto.ParametersDTO;
import it.contrader.dto.PlayersDTO;
import it.contrader.service.*;
//import it.contrader.service.Service;
//import it.contrader.service.UserService;

/*
 * Per dettagli vedi Guida sez Servlet
 */
public class ServletDeviceUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
    LoginService check = new LoginService();
    Service<DeviceDTO> service ;
    String Heartbeat1 ;
	String Pressure1 ;
	String Breath1 ;
	 String idplay1 ;
	  int id1;
    
    
	public ServletDeviceUp() {
	}
	
 	public void updateList(HttpServletRequest request) {
		Service<DeviceDTO> service = new DeviceService();
		
		List<DeviceDTO> listDTO = service.getAll();
		request.setAttribute("listdevice", listDTO);
	} 
 	
 	public void updateListPlayers(HttpServletRequest request) {
		Service<PlayersDTO> service = new PlayersService();
		
		List<PlayersDTO> listDTO = service.getAll();
		request.setAttribute("listplayers", listDTO);
	} 
 	
 	public boolean checkNumberFormat(String string){
		  boolean var=false;
		  
		  try{
			Integer.parseInt(string);
			var=true;
		  }
		  catch(NumberFormatException e){
			  
			 var=false; 
		  }
		return var;
	}

	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 	Service<DeviceDTO> service = new DeviceService();
		String mode = request.getParameter("mode");
		DeviceDTO dto;
	    DeviceDTO user;
	    String usertypeCheck;
		int id;
		boolean ans;

		switch (mode.toUpperCase()) { 

		case "USERLIST":
			updateList(request);
			updateListPlayers(request);
			getServletContext().getRequestDispatcher("/user/Devicemanager.jsp").forward(request, response);
			
			break; 
		case "DELETE":
		 
		 id1 = Integer.parseInt(request.getParameter("id"));
		 Service<DeviceDTO> service3 = new DeviceService();
		 if(service3.delete(id1)){
			Service<DeviceDTO> service4 = new DeviceService();
			DeviceDTO dtodevice = new DeviceDTO(0,0,0);
			          service4.insert(dtodevice);
			request.setAttribute("control_si_non", "Operazione avvenuto con successo !!!");
			 updateList(request);
				updateListPlayers(request);
				getServletContext().getRequestDispatcher("/user/Devicemanager.jsp").forward(request, response);	 
		 }
		 else{
			 request.setAttribute("control_si_non", "Operazione non avvenuto con successo !!!");	 
			    updateList(request);
				updateListPlayers(request);
				getServletContext().getRequestDispatcher("/user/Devicemanager.jsp").forward(request, response);	 
			 
		 }
			
			  break;
			  
		case "UPDATE":
			idplay1  =(String)request.getParameter("idplay");
			Heartbeat1  =(String)request.getParameter("heartbeat");
			Pressure1 =(String) request.getParameter("pressure");
			Breath1 =(String) request.getParameter("breath");
			
			if((Heartbeat1 !="") && (Pressure1 !="") 
				 	  && (Breath1 !="") && (idplay1 !="")
				 			
				 			){
				 	
				 	if(checkNumberFormat(Heartbeat1) &&  checkNumberFormat(idplay1) &&
				 	    checkNumberFormat(Pressure1) &&   checkNumberFormat(Breath1)  
				 			){
				 	// si salve nella tabella 
				 		
				 		int heartbeat = Integer.parseInt(Heartbeat1);
				 		int pressure = Integer.parseInt(Pressure1);
				 		int breath =Integer.parseInt(Breath1);
				 		int idplay =Integer.parseInt(idplay1);
				 		
				 		
				 		
				 		DeviceDTO ddto1=new DeviceDTO(idplay,heartbeat,pressure,breath);
				 		Service<DeviceDTO> service6 = new DeviceService();
				 		  if(service6.update(ddto1)){
				 		 request.setAttribute("control_si_non", " Operazione eseguita con successo!!!");	
				 		 updateList(request);
							updateListPlayers(request);
							getServletContext().getRequestDispatcher("/user/Devicemanagerup.jsp").forward(request, response);	 
				 		  }
				 		  else{
				 			 request.setAttribute("control_si_non", " Operazione non eseguita con successo pb ID di servizio!!!");	
					 		 updateList(request);
								updateListPlayers(request);
								getServletContext().getRequestDispatcher("/user/Devicemanagerup.jsp").forward(request, response);	 	  
				 		  }
				 		
				 		 
				 		  
				 		  }
				 	
				 	else{
				 		request.setAttribute("control_si_non", " Almeno uno campo non possiede un number intero!!!");
				 		 updateList(request);
							updateListPlayers(request);
							getServletContext().getRequestDispatcher("/user/Devicemanagerup.jsp").forward(request, response);	 
				 	}
				 	
				 	
				 	}
				 	else{
				 		request.setAttribute("control_si_non", "Almeno uno campo � vuoto !!!");
				 		 updateList(request);
							updateListPlayers(request);
							getServletContext().getRequestDispatcher("/user/Devicemanagerup.jsp").forward(request, response);	 
				 	} 	
			
			
			
			  break;
		case "INSERT":
			
			Heartbeat1  =(String)request.getParameter("heartbeat");
			Pressure1 =(String) request.getParameter("pressure");
			Breath1 =(String) request.getParameter("breath");
			
			if((Heartbeat1 !="") && (Pressure1 !="") 
				 	  && (Breath1 !="") 
				 			
				 			){
				 	
				 	if(checkNumberFormat(Heartbeat1) && 
				 	    checkNumberFormat(Pressure1)	&&   checkNumberFormat(Breath1)  
				 			){
				 	// si salve nella tabella 
				 		
				 		int heartbeat = Integer.parseInt(Heartbeat1);
				 		int pressure = Integer.parseInt(Pressure1);
				 		int breath =Integer.parseInt(Breath1);
				 		
				 		DeviceDTO ddto=new DeviceDTO(heartbeat,pressure,breath);
				 		Service<DeviceDTO> service5 = new DeviceService();
				 		             service5.insert(ddto);
				 		request.setAttribute("control_si_non", " Operazione eseguita con successo!!!");	
				 		 updateList(request);
							updateListPlayers(request);
							getServletContext().getRequestDispatcher("/user/Devicemanager.jsp").forward(request, response);	 
				 	}
				 	
				 	else{
				 		request.setAttribute("control_si_non", " Almeno uno campo non possiede un number intero!!!");
				 		 updateList(request);
							updateListPlayers(request);
							getServletContext().getRequestDispatcher("/user/Devicemanager.jsp").forward(request, response);	 
				 	}
				 	
				 	
				 	}
				 	else{
				 		request.setAttribute("control_si_non", "Almeno uno campo � vuoto !!!");
				 		 updateList(request);
							updateListPlayers(request);
							getServletContext().getRequestDispatcher("/user/Devicemanager.jsp").forward(request, response);	 
				 	} 	
			
			
			  break;
			 
		case "UPDATETEMP":
			 updateList(request);
				updateListPlayers(request);
				getServletContext().getRequestDispatcher("/user/Devicemanagerup.jsp").forward(request, response);	 
			break;

	
		     
		}
	}
}