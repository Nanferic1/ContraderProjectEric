package it.contrader.dto;

public interface DTO {
	
}
