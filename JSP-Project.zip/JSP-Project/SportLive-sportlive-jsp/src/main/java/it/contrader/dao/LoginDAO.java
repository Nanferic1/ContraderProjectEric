package it.contrader.dao;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import it.contrader.utils.ConnectionSingleton;
import it.contrader.model.User;

/**
 * 
 * @author Vittorio
 *
 *Per i dettagli della classe vedi Guida sez 6: DAO
 */
public class LoginDAO {

	private final String QUERY_LOGIN = "SELECT * FROM user WHERE username = ? AND password = ?";
	private final String QUERY_LOGIN_PLAYER = "SELECT * FROM tableplayers WHERE nickname = ? AND password = ?";
	private final String QUERY_CREATE = "INSERT INTO tableplayers (id, nickname, password, playertype, score) VALUES (?,?,?,?,?)";
	
	
	public User playerCreate(String nickname, String password,String playertype){
		 User user=null;
		
		return user;
		
	}
	
	
	public User login (String username, String password) {
		System.out.println();
		User user=null ;
		int id =0;
		String  usertype=null;
		
		username=username.toLowerCase();
		password=password.toLowerCase();
		
		if((username.equals("player") && password.equals("player"))){
			Connection connection = ConnectionSingleton.getInstance();
			
			
			
			try {
				PreparedStatement statement = connection.prepareStatement(QUERY_LOGIN_PLAYER);

				statement.setString(1, username);
				statement.setString(2, password);

				
				ResultSet resultSet;
				
				if(statement.executeQuery().next()) {
					resultSet = statement.executeQuery();
					resultSet.next();
					usertype = resultSet.getString("playertype");
					 id = resultSet.getInt("id");
					
				}
				 user = new User(id, username, password, usertype);		
				
		}
			catch(SQLException e ){
				
			}
		}
		
		else if(
		   (username.equals("admin") && password.equals("admin")) || (username.equals("coach") && password.equals("coach")) ||
		   (username.equals("device") && password.equals("device")) || (username.equals("parameters") && password.equals("parameters"))
		    
			){ 
		
		
		Connection connection = ConnectionSingleton.getInstance();
		
		
		
		try {
			PreparedStatement statement = connection.prepareStatement(QUERY_LOGIN);

			statement.setString(1, username);
			statement.setString(2, password);

			
			ResultSet resultSet;
			
			if(statement.executeQuery().next()) {
				resultSet = statement.executeQuery();
				resultSet.next();
				usertype = resultSet.getString("usertype");
				 id = resultSet.getInt("id");
				
			}
			
			   
				
			 if(usertype=="devive" && (username.equals("device")|| password.equals("device")))
					   {	
				    user = new User(-1,username, password, "DEVICE_NON");	
				}
				if(usertype=="parameters" && ( username.equals("parameters") || password.equals("parameters")))
				   {	
			    user = new User(-1,username, password, "PARAMETERS_NON");	
			}
				if(usertype=="coach" && ( username.equals("coach") || password.equals("coach")))
				   {	
			    user = new User(-1,username, password, "COACH_NON");	
			}
				if(usertype=="admin" && ( username.equals("admin") || password.equals("admin")))
				   {	
			    user = new User(-1,username, password, "ADMIN_NON");	
			}
				
				
				
				if((usertype==null)){
					 user = new User(id, username, password,"INSERISCI");	
					}
				   	
				
				
				if(!(usertype==null)){
				 user = new User(id, username, password, usertype);	
				}
			   
				
				
			
			
			//return null;
		}
		
		catch (SQLException e) {
			
			return null;
		}
		
		 } // end if aggiunto
		
		else {
			 user = new User(0, "utenteN", "utenteN", "UTENTENONRICONOSCIUTO");	
		} 
		return user;
		
		
	}   // end metodo 
	
	
}