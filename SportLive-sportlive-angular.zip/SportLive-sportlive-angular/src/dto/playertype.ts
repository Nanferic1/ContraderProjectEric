export enum Playertype {
    ATT,
    CEN,
    DIF,
    POR
}
