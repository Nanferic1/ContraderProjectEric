export enum Usertype {
    ADMIN,
    DEVICE,
    PLAYER,
    COACH

}
