export class DeviceDTO {
    id:number;
    idplayer: number;
    serial:number;
    heartbeat:number;
	pressure:number;
}