import {Playertype} from './playertype';

export class PlayerDTO {

    id: number;

    idPlayer: number;

    idCoach: number;

    playername: string;

    playertype: Playertype;

    age: number;

    gamep: number;

    score: number;
}
