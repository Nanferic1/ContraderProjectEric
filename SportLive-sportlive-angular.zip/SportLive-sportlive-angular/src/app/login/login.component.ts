import { Component, OnInit } from '@angular/core';
import { LoginDTO } from 'src/dto/logindto';
import { NgForm } from '@angular/forms';
import { UserService } from 'src/service/user.service';
import { Router } from '@angular/router';
//export var goToPlace: boolean;


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    private username: string;
    private password: string;
    private message: string;
    private ctrl: boolean;
    private playertrue: boolean;
    private goToPlace: boolean;
   
   

  loginDTO: LoginDTO;

    constructor(private service: UserService, private router: Router) {
        this.message = "Niente per adesso !!!";
        this.ctrl = false;
        this.playertrue = false;
        this.goToPlace = false;
      
    }

  ngOnInit() {
  }

  //login(f: NgForm): void {

  // login(f): void {
    nomeUtente(value) {
        this.username = value;
    }
    passUtente(value) {
        this.password = value;
    }

  /*  goPlaces1(): boolean {
     return false;
    } */
    /*goPlacePlayer(): boolean {
     
        if (this.playertype2.valueOf["PLAYER"] === 2) {
            return true;
        }
        else {
            return false;
        }
    }*/
    goPlaces2(): void {
        this.router.navigate(['/admin-dashboard/', 'player']).then(
            nav => {
                console.log('Navigazione is: ' + nav);
                err => {
                    console.log('Navigazione is '+ err);
                }
        });
    }
    goPlaces3(redirect1: string, redirect2: string) {
        this.router.navigate([redirect1, redirect2]).then(
            nav => {
                console.log('Navigazione is: ' + nav);
                err => {
                    console.log('Navigazione is ' + err);
                }
            });
    }

    login() {
     // this.loginDTO = new LoginDTO(f.value.username, f.value.password);

        console.log('username:' + this.username + ' and ' + 'password is: ' + this.password);

      
 
        //  this.loginDTO = new LoginDTO(f.form.value.username, f.form.value.password);
        this.loginDTO = new LoginDTO(this.username, this.password);

      this.service.login(this.loginDTO).subscribe((user) => {

          if (user === null) {
              // this.router.navigate(['/admin-dashboard']);
              this.ctrl = true;
              this.message = "Impossibile accedere al servizio! Utente non registrato dall'amministratore";
          }

      if (user != null) {
        localStorage.setItem('currentUser', JSON.stringify(user));

        switch (user.usertype.toString()) {
          case 'ADMIN': {
                this.router.navigate(['/admin-dashboard']);
                localStorage.setItem('use', JSON.stringify("Administratore"));

            break;
            }
            case 'PLAYER': {
         
               // this.router.navigate(['/admin-dashboard/player']);
                this.playertrue = true;
               // this.goPlaces1() ;

               // this.goPlaces2(); pu� anche andare bene per un accesso diretto alle risorse dell'entit� soggetto
                localStorage.setItem('use', JSON.stringify("Giocatore"));
                
                break;
            }
            case 'DEVICE': {
               // this.router.navigate(['/admin-dashboard/device']);
                this.goPlaces3('/admin-dashboard/', 'device');
                localStorage.setItem('use', JSON.stringify("Dispositivo"));
                break;
            }
            case 'COACH': {
                localStorage.setItem('use', JSON.stringify(false));
                localStorage.setItem('coachId', JSON.stringify(user.id));
                localStorage.setItem('coachUser', JSON.stringify(user.username));
                localStorage.setItem('use', JSON.stringify("Allenatore"));
                this.router.navigate(['/admin-dashboard/coach']);
            break;
          }
          default:
          
                this.ctrl = true;
                this.message = "Impossibile accedere al servizio! Utente non registrato dall'amministratore";
        } 
      } 
    }); 
  } 
}
