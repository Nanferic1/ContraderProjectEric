import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/service/user.service';
import { UserDTO } from 'src/dto/userdto';
import { PlayerDTO } from 'src/dto/playerdto';
import { PlayerService } from 'src/service/player.service';
import { Usertype } from 'src/dto/usertype';
import { DeviceService } from 'src/service/device.service';
import { DeviceDTO } from 'src/dto/devicedto';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

    users: UserDTO[];
    usertoinsert: UserDTO = new UserDTO();
    players1: PlayerDTO[];
    devices: DeviceDTO[];
    ID_players: Array<number> ;
    Name_players: Array<string>;
    playersPerCoach: Array<string>;
    listDevice: Array<string>;
    lDevice: Array<number>;
    ManageCoach: Array<number | string>;
    ManageCoach1 = new Array<number>();
    ManageCoach2 = new Array<string>();
    IDCoachPlayer: Array<number | string>;
    FiltraRidondanza: Array<number | string>;
    iDCoachPlayer: Array<number>;
    ID_coach: Array<number>;
    salvaID: Array<number>;
    SalvaID: Array<number> = new Array<number>();
    newSalva: Array<number> = new Array<number>();
    clicca = false;
    modelDelete: string;
    Index: number;
    ID: number;
    ctrl = 0;
     s = 0;
    compact: Array<string>;
    cancel1 = false;
    cancel2 = false;
    cancel3 = false;
    cancel4 = false;
    mess1: string;    
    mess2: string;
    mess3: string;
    mess4: string;
    m1: boolean;
    m_1: string;
    bestID = 0;
    attive_button = false;
    messDevice = '';
    arrayNonVuoto = false;
    trovato=0;
    imposs = false;
    v = false;
    params = false;
    canc = false;
    cas: number;
    constructor(private service: UserService, private playerservice: PlayerService, private deviceService: DeviceService) {

       // this.compact = new Array<string>();
        this.listDevice = new Array<string>();
        localStorage.setItem('device', JSON.stringify(0));
        this.lDevice = new Array<number>();
        this.Name_players = new Array<string>();
        this.ID_players = new Array<number>();
        this.ID_coach = new Array<number>();
        this.ID = 0;
        this.FiltraRidondanza = new Array<number | string>();
       

    }

  ngOnInit() {
      this.getUsers();
      this.getPlayers();
      this.getDevice();
      if (this.ID_players.length != 0) {
          this.takeMaxIdPlayer(this.ID_players);
      }
     
    
  }

    // La maggior parte delle librerie usate caricano le risorse oppure i modelli da 
    // manipolare nel file HTML, per� come detto nel ts del coach, qua i metodo sono stati 
    // gestiti e usati molto di pi� nel ts user rispetto al HTML users 

    setArray(): void {                              //################# usare anche per il player all'avvio di richiesta
        this.ID_players = new Array<number>();
        this.Name_players = new Array<string>();
        this.ID_coach = new Array<number>();
        this.ID = 0;
       // this.params = false;
       // this.m1 = false;
    }
  getUsers() {
      this.service.getAll().subscribe(users => this.users = users);
    
     
  }
    getDevice(): void {
        this.deviceService.getAll().subscribe((devices1: DeviceDTO[]) => { this.devices = devices1 });
    }
    getPlayers(): void {
        this.playerservice.getAll().subscribe((players1: PlayerDTO[]) => { this.players1 = players1 });
      
    }

    delete(user: UserDTO) {
        if (user.usertype.toString() === 'ADMIN') {
            this.service.delete(user.id).subscribe(() => this.getUsers());
        }
        else if (user.usertype.toString() === 'COACH') {
            this.canc = true;
            this.deleteCoachInAdmin(user.id);
            this.salvaIDPlayerCoach(user.id,this.SalvaID, this.ID_players);
            this.deleteCoachtabellaPlayers(this.salvaID);
            if ((this.m1) && (this.params)) {
                this.m_1 = "Cancellazione del modello coach e liberazione dei players per altri coach avvenuto con successo !!!";
            }
            else if ((this.m1) && !(this.params)) {
                this.m_1 = "Cancellazione del modello coach dalla tabella admin avvenuto con successo !!!";
            }
            this.setValori1();


        }
        else if (user.usertype.toString() === 'DEVICE') {
            this.deviceTabellaAdmin(user.id);
            this.deleteListaDevice(this.lDevice);
            if ((this.m1) && (this.params)) {
               this.m_1 = "Cancellazione del modello device e parametri device avvenuto con successo !!!";
            }
            else if ((this.m1) && !(this.params)) {
                this.m_1 = "Cancellazione del modello device avvenuto con successo !!!";
            }
           


        }
        else if (user.usertype.toString() === 'PLAYER') {
            this.OnTrue();
            this.service.delete(user.id).subscribe(() => this.getUsers());
            this.m1 = true;
            this.DeleteMethod(this.Name_players, this.ID_players, user.username);
            if (this.ID != 0) {
                this.CancPlayer(this.ID);
            }
            if ((this.m1) && (this.params)) {
                this.m_1 = "Cancellazione del modello player e parametri del player avvenuto con successo !!!";
            }
            else if ((this.m1) && !(this.params)) {
                this.m_1 = "Cancellazione del modello players dalla tabella admin avvenuto con successo !!!";
            }
            this.setArray();
           
      }
     

        
    }

/* controlla la cancellazione del device lato admin e tutti i suoi parametri 
 * /////////////////////////////////////////////////////////////////////////
 *//////////////////////////////////////////////////////////////////////////*/


    deviceTabellaAdmin(userId: number): void{
        this.service.delete(userId).subscribe(() => this.getUsers());
        this.m1 = true;
       }
 
    userDevice(username: string): boolean {
        if (username !== null) {
            this.v = true;
           // console.log('V: ' + this.v);
        }
       
       
        return true;
    }

    salvaIdDevice(p: number): boolean {
        if (p != 0) {
            //  this.lDevice.push(d);

            let m = 0;
            let b = 0;
            if (this.lDevice.length === 0) {
                this.lDevice.push(p);
            }
            else {
                for (b = 0; b < this.lDevice.length; b++) {
                    m++;
                    if (p === this.lDevice[b]) {
                        break;
                    }
                    else {
                        if (m === this.lDevice.length) {
                            this.lDevice.push(p);
                        }

                    }
                }
            }
        }
        return true;
    }
   

    deleteListaDevice(f: Array<number>): void {
        if (f.length != 0) {
            for (let n = 0; n < f.length; n++) {
                this.deviceService.delete(f[n]).subscribe();
            }
            this.params = true;
          
        }

        
    }
    /* ////////////////////////////////////////////////////////////////////////
     * ////////////////////////////////////////////////////////////////////////
     * ///////////////////////////////End control device /////////////////////*/


  /*//////////////////////////////////////////////////////////////////////////
   * ////////////////////////////////////////////////////////////////////////
   * ////////////////Gestione della delete del coach////////////////////////
   * ///////////////////////////////////////////////////////////////////////*/

    deleteCoachInAdmin(userID: number): void {                                    // 1
        this.service.delete(userID).subscribe(() => this.getUsers());
        this.m1 = true;
       }
    deleteCoachtabellaPlayers(occorenzaPlayers: Array<number>): void {            //  3
        let m = occorenzaPlayers.length;
        let n = 0;
        if (this.ctrl > 0) {
            this.params = true;       // settare anche 
            if (m != 0) {
                do {
                    this.playerservice.delete(occorenzaPlayers[n]).subscribe(() => this.getPlayers);
                    m--;
                    n++;
                } while (m != 0);
            }
        }
        this.ctrl = 0;
    }

    salvaIDPlayerCoach(IdCoach: number, listaCoachPlayers: Array<number>, listaPlayers: Array<number>): void {  //  2 ##############################################
        this.salvaID = new Array<number>();
        console.log('Lista Players : ' + listaPlayers);
        console.log('Coach ID Players : ' + listaCoachPlayers);
       
        for (let n = 0; n < listaCoachPlayers.length; n++) {
            if (listaCoachPlayers[n] === IdCoach) {
                this.salvaID.push(listaPlayers[n]);    // mi serve un altra memoria per una eventuale delete coach 
                this.ctrl++;                          // si capisce se ci sono coach che mappano id players,poi ctrl = 0
            }

        }
        console.log('ID Players : ' + this.salvaID);
        console.log('Ctrl : ' + this.ctrl);

    }

    setValori1(): void {
        this.salvaID = new Array<number>();
      }


    //-------------------------------------------------------------------

    Model(a: number, b: string, c: UserDTO): boolean {

        if ((a != 0) && (c.usertype.toString()==='COACH')) {
            this.ManageCoach.push(a);
        }
        if ((b != null) && (c.usertype.toString() === 'COACH')) {
            this.ManageCoach.push(b);
        }
        return true;
    } 
    stampa(): boolean {

        console.log('Lista1: ' + this.newSalva);
       return true ;
    }

   

    IDCoach(q: number, c: UserDTO): boolean {                // acquisce un intero Id e prova a capire se c'� gi� nel array
        let m = 0;
        let b = 0;
        // this.trovato = false;
       
        if (c.usertype.toString() === 'COACH') {
            if (this.ManageCoach1.length === 0) {
                this.ManageCoach1.push(q);
              
            }
            else {
                for (b = 0; b <this.ManageCoach1.length; b++) {
                    m++;
                    if (q === this.ManageCoach1[b]) {
                        break;
                    }
                    else {
                        if (m === this.ManageCoach1.length) {

                            this.ManageCoach1.push(q);
                           


                        }

                    }
                }
            }

        }
        return true;
    } 
    UserCoach(q: string, c: UserDTO): boolean {                // acquisce una stringa e prova a capire se c'� gi� nel array
        let m = 0;
        let b = 0;
        // this.trovato = false;

        if (c.usertype.toString() === 'COACH') {
            if (this.ManageCoach2.length === 0) {
                this.ManageCoach2.push(q);

            }
            else {
                for (b = 0; b < this.ManageCoach2.length; b++) {
                    m++;
                    if (q === this.ManageCoach2[b]) {
                        break;
                    }
                    else {
                        if (m === this.ManageCoach2.length) {

                            this.ManageCoach2.push(q);



                        }

                    }
                }
            }

        }
        return true;
    }
    UsaCombination(a: Array<number>, b: Array<string>): void {   // Array multitype 
        let i = 0;
        let j = 0;
        this.ManageCoach = new Array<number | string>();
        if (a.length != 0 && b.length != 0) {
            do {
                this.ManageCoach.push(a[i]);
                this.ManageCoach.push(b[j]);
                i++;
                j++;

            } while (i < a.length && j < b.length);
        }
    }

    recuperaIdPlayerCoach(t: number): void {

        this.iDCoachPlayer = new Array<number>();



    }
   


    deleteListaPlayerCoach(f: Array<number | string>): void {  //############ Non serve ###################
        if (f.length != 0) {
            for (let n = 0; n < f.length; n++) {
                // this.deviceService.delete(f[n]).subscribe();

            }
            this.params = true;

        }

    }

    UsaCombination2(a: Array<number>, b: Array<string>): boolean {   // Array multitypes 
        let i = 0;
        let j = 0;
        this.IDCoachPlayer = new Array<number | string>();
        if (a.length != 0 && b.length != 0) {
            do {
                this.IDCoachPlayer.push(a[i]);
                this.IDCoachPlayer.push(b[j]);
                i++;
                j++;

            } while (i < a.length && j < b.length);
        }
        return true;
    }

 /*   filtraModelli(lista: Array<number | string>): boolean {         // filtra per� c'� ridondanza nella chiamata
        let u = 0;
        this.FiltraRidondanza  = new Array<number | string>();
        if (lista.length != 0) {
            for (let i = 0; i < lista.length; i++) {
                if (i == 0) {
                    this.FiltraRidondanza.push(lista[i]);
                }
                else {
                    if (lista[i] != this.FiltraRidondanza[u]) {
                        this.FiltraRidondanza.push(lista[i]);
                        u++;
                    }
                }
            }
        }

        return true;
    } */
    getCoachID(q: number): boolean {                // acquisce una stringa e prova a capire se c'� gi� nel array per il blocco coach delete nel caso di uso 
        let m = 0;
        let b = 0;
        // this.trovato = false;

        if (this.ID_coach.length === 0) {
            this.ID_coach.push(q);

        }
        else {
            for (b = 0; b < this.ID_coach.length; b++) {
                m++;
                if (q === this.ID_coach[b]) {
                    break;

                }
                else {
                    if (m === this.ID_coach.length) {

                        this.ID_coach.push(q);
                    }

                }
            }
        }
        //  console.log('ID Players ' + this.ID_players);

        return true;
    } 
    /*/////////////////////////////////////////////////////////////////////
     * ///////////////////End Coach delete ////////////////////////////////
     * ////////////////////////////////////////////////////////////////////*/

    messageButton(): void {
        this.attive_button = true;
       
       
    }

    Pulisci(): void {
        if (this.cancel1) {
            this.mess1 = '';
            this.cancel1 = false;
            this.attive_button = false;
        }
        if (this.cancel2) {
            this.mess2 = '';
            this.cancel2 = false;
            this.attive_button = false;
        }
        if (this.cancel3) {
            this.mess3 = '';
            this.cancel3 = false;
            this.attive_button = false;
        }
        if (this.cancel4) {
            this.mess4 = '';
            this.cancel4 = false;
            this.attive_button = false;
        }
       
        if (this.m1) {
            this.m1 = false;
            this.m_1 = '';
            this.attive_button = false;
            this.params = false;
            this.ctrl = 0;
        }
    
       

      

    }

  update(user: UserDTO) {
    this.service.update(user).subscribe(() => this.getUsers());
  }

    insert(user: UserDTO) {
       
        if ( (user.usertype.toString() != 'DEVICE') ) { 
            this.service.insert(user).subscribe(() => this.getUsers());
                this.m1 = true; 
                this.m_1 = "Inserimento  avvenuto con successo !!!";
            
      
        }

        if (user.usertype.toString() === 'DEVICE') {
            if (this.v) {
                this.m1 = true;
                this.m_1 = "Impossible Insert since devive have been created !!!";
            }
            else {
                this.service.insert(user).subscribe(() => this.getUsers());
                this.m1 = true;
                this.m_1 = "Inserimento  avvenuto con successo !!!";
            }
        }
       
    }

   

  clear(){
      this.usertoinsert = new UserDTO();
      
  }
    OnTrue(): boolean {
        this.clicca = true;
        return true;
    }

    /*/////////////////////////////////////////////////////////////////////
     * ///////////////////////////////////////////////////////////////////
     * /////////////// Gestione delete Player/////////////////////////////
     * ///////////////////////////////////////////////////////////////////
     * ///////////////////////////////////////////////////////////////////*/
      
   

    DeleteMethod(p: Array<string>, q: Array<number>,h: string) : void {                 // ricava l'id da delete in Player per domani  

        if (p.length != 0 && q.length != 0) {
           
            for (let m = 0; m < p.length; m++) {
                if (p[m] === h) {
                    this.Index = m;
                 
                }
            }  

            for (let n = 0; n < q.length; n++) {
                if (n === this.Index) {
                    this.ID = q[n];
                }
            }

            console.log('ID delete: ' + this.ID);

        }
      //  return true;
    }

    CancPlayer(p: number): void {
        
        this.playerservice.delete(p).subscribe(() => this.getPlayers());
        this.params = true;
       
      
    }

  

    getPlayersName(p: string): boolean {                // acquisce una stringa e prova a capire se c'� gi� nel array
        let m = 0;
        let b = 0;
        // this.trovato = false;
        if (this.Name_players.length === 0) {
            this.Name_players.push(p);
          
        }
        else {
            for (b = 0; b < this.Name_players.length; b++) {
                m++;
                if (p === this.Name_players[b]) {
                    break;
                }
                else {
                    if (m === this.Name_players.length) {

                        this.Name_players.push(p);

                    }

                }
            }
        }
       
         return true;
    }

    getPlayersID(q: number): boolean {                // acquisce una stringa e prova a capire se c'� gi� nel array
        let m = 0;
        let b = 0;
        if (this.ID_players.length === 0) {
            this.ID_players.push(q);

        }
        else {
            for (b = 0; b < this.ID_players.length; b++) {
                m++;
                if (q === this.ID_players[b]) {
                    break;
                }
                else {
                    if (m === this.ID_players.length) {

                        this.ID_players.push(q)
                    }

                }
            }
        }
     

        return true;
    }

    provaIdCoach(a: number): boolean {     // acquisce gli Id coach,per� sembra che la tech pone problemi di ridondanza,cerchiamo di usarli per via dei riferimenti,guadare giu visto che il riferimento � l'array di ID Players cosi si riduce il raggio di azione di dati

        //   if (this.s < this.ID_players.length) {
        this.SalvaID.push(a);
        //     console.log('StampaID :' + this.SalvaID[this.s])
        //   } 

        /*   if (this.s === this.ID_players.length) {
               this.SalvaID = new Array<number>();
               this.s = 0;
           }
           this.s++; */
        return true;
    }

    InserisciIdCoachConvenienza(allIDPlayer: Array<number>): boolean {  // Si prende solo i primi valori dei coach che servono visto la ripetizione di valori o introduzione di errori nei calcoli,potrebbe essere intenzionale da parte della tecn,vediamo nelle versioni seguenti
        this.newSalva = new Array<number>();
        let n = 0;
        for (let i = 0; i < this.ID_players.length; i++) {
            n++;
            this.newSalva.push(this.SalvaID[i]);
            if (n === this.ID_players.length) {
                n = 0;
                break;
            }
        }
        console.log('NewSalva: ' + this.newSalva)
        return true;
    }

    takeMaxIdPlayer(allIDPlayer: Array<number>): boolean {   // Funziona bene anche se non � stato usato
        if (allIDPlayer.length != 0) {
            for (let i = 0; i < allIDPlayer.length; i++) {
                if (i === allIDPlayer.length - 1) {
                    this.bestID = allIDPlayer[i];

                }
            }
        }

        console.log('BestID: ' + this.bestID);
        return true;

    }

 
   

   

//////////////////////////////////////End Players Cancel //////////////////////////////////////////

}
