import { Component, OnInit } from '@angular/core';
import { PlayerService } from 'src/service/player.service';
import { PlayerDTO } from 'src/dto/playerdto';
import { LoginComponent } from 'src/app/login/login.component';
import { UserDTO } from 'src/dto/userdto';
@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})
export class PlayerComponent implements OnInit {

    players: PlayerDTO[];
    playertoinsert: PlayerDTO = new PlayerDTO();
    login: LoginComponent = new LoginComponent(null, null);
    private userdto1: UserDTO;
     userx: string ;
   
   
    constructor(private service: PlayerService) {

        this.userx = JSON.parse(localStorage.getItem('use'));
      
       
    }

  ngOnInit() {
    this.getPlayers();
      console.log("Sono qui");
     
  }
   /* getUserCorrente(): boolean {
        this.k = JSON.parse(localStorage.getItem('use'));
        console.log('User ' + this.k);
        return true;
    }*/

  /*  getTrue(): void {
        if (this.userdto1 != null) {
            if (this.userdto1.usertype.toString() === 'PLAYER') {
                this.k = true;
            }
        }
        else {
            this.k1 = true;
        }
        
        } */

  getPlayers() {
      // this.service.getAll().subscribe(players => this.players = players);
      this.service.getAll().subscribe((players: PlayerDTO[]) => { this.players = players; console.log('Players log: ' + players) });
    console.log("sono nella get players--: " + this.players);
  }

  delete(player: PlayerDTO) {
    this.service.delete(player.id).subscribe(() => this.getPlayers());
  }

  update(player: PlayerDTO) {
    this.service.update(player).subscribe(() => this.getPlayers());
  }

  insert(player: PlayerDTO) {
    this.service.insert(player).subscribe(() => this.getPlayers());
  }

  clear(){
    this.playertoinsert = new PlayerDTO();
  }
}
