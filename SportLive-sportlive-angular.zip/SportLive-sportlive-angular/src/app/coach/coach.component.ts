import { Component, OnInit } from '@angular/core';
import { PlayerService } from 'src/service/player.service';
import { PlayerDTO } from 'src/dto/playerdto';
import { UserService } from 'src/service/user.service';
import { UserDTO } from 'src/dto/userdto';
import { Usertype } from 'src/dto/usertype';
import { Playertype } from 'src/dto/playertype';
import { Router } from '@angular/router';

@Component({
  selector: 'app-coach',
  templateUrl: './coach.component.html',
  styleUrls: ['./coach.component.css']
})
export class CoachComponent implements OnInit {

    players: PlayerDTO[];
    players1: PlayerDTO[];
    playersCoach: PlayerDTO[];
    users: UserDTO[];
    playerdto: PlayerDTO = new PlayerDTO();
    usertype: Usertype;

    playertoinsert: PlayerDTO = new PlayerDTO();
    idcoach: number;
    i: number;
    k: number;
    var1: boolean;
    message: number;
    userx: string;
    coachUsername: string;
    playersusers: Array<string> = new Array < string>();
    players_users: Array<string> = new Array<string>() ;
    diffPlayers: Array<string> = new Array<string>();
    playersPerCoach: Array<string> = new Array<string>();
    resultPlayers: Array<string>;
    filtrare: Array<string> = new Array<string>();
    idList: Array<number> = new Array<number>();
    h = 0;
    w = 0;
    v = 0;
    trovato = 0; 
    number = 0;
    reste = 0;
    idx: number;
    idplayerx: number;
    idcoachx: number;
    playernamex: string;
    agex: number;
    gamepx: number;
    scorex: number;
    idbest: number;
    nome = '';
    si_puo: boolean;
    m1 = false;
    mess = '';
    va_bene1: boolean;
    va_bene2: boolean;
    do = false;
    create1 = false;
    create2 = false;
    clique = false;
    deleteBottone = false;
    createBottone = false;
    resto = 0;
    p = 0;
   
    /*///////////// Rispetto al lavoro compiuto sul ts dello user grand parte del lavoro � stato realizzato con chiamate ////////////////
    */////////////sul file dedicato alla vista ovvero HTML file del coach //////////////////////////////////////////////////////////////
     ////////////// Cmq l'importante � capire quello che si vuole realizzare e cercare di portare a termine in uno dei modi /////////////*/
     

    constructor(private playerService: PlayerService, private userService: UserService, private router: Router) {
        // this.getPlayers();
        this.idcoach = 0;
        this.i = 0;
        this.k = 0;
        this.message = null;
        this.coachUsername = JSON.parse(localStorage.getItem('coachUser'));
        this.playerdto.id = 0;
        this.playerdto.idCoach = JSON.parse(localStorage.getItem('coachId'));
        this.playerdto.idPlayer = 0;
        this.playerdto.playername = "vuoto";
        this.playerdto.age = 0;
        this.playerdto.gamep = 0;
        this.playerdto.score = 0;
        this.userx = JSON.parse(localStorage.getItem('use'));
     
       

    }

    ngOnInit() {
        this.var1 = false;
        this.getPlayers();
        this.getUsers();
      
      
     
    }

    goPlaces3(redirect1: string, redirect2: string) {
        this.router.navigate([redirect1, redirect2]).then(
            nav => {
                console.log('Navigazione is: ' + nav);
                err => {
                    console.log('Navigazione is ' + err);
                }
            });
    }

    Reload(): void {                                    // Non funziona adesso,il processo � assai complesso
        this.goPlaces3('/admin-dashboard/', 'coach');
    }

     /* ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// */
    /* Si cerca di capire se il coach ha la possibilit� o il diritto di inseri un giocatore visto dovrebbe dipendere da l'acquisto ovverp dell'Admin del sistema   */
/* ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/

   

    setUtilita(): void {
        this.va_bene1 = false;
        this.va_bene2 = false;
        this.si_puo = false;
        this.m1 = false;
        this.mess = '';
      
    }

   
    acquiscePlayer(playernome: string): boolean {
        this.setUtilita();
        this.nome = playernome;
        this.playersInLista(playernome);

        return true;
    }


    playersInLista(nome: string): void {
        if ((nome != null) && (this.playersusers.length > 0)) {    // Il giocatore esiste in admin
            for (let n = 0; n < this.playersusers.length; n++) {
                if (this.playersusers[n] === nome) {                        
                    this.va_bene1 = true;
                }
            }
        }
        let y = 0;
        for (let m = 0; m < this.players_users.length; m++) {  // e non � occupato da un coach
                if (nome != this.players_users[m]) {                
                    y++;
                    if (y === this.players_users.length) this.va_bene2 = true;

                }
            }

                if ((this.va_bene1===true) && (this.va_bene2===true)) {
                    this.si_puo = true;
                  
                }

    }

    goTo():   void {
        this.playersusers = new Array<string>();
        this.players_users = new Array<string>();
        this.diffPlayers = new Array<string>();
        this.filtrare = new Array<string>();
       
  }

    Stampa() {
        console.log('DIFF PLAYERS ' + this.diffPlayers);
    }
    

    ////////////////////////////////////////////////////////// End control identificazione /////////////////////////////////////////////////////////////////////////*/


   





    getPlayers_Coach(p: string): boolean {                // acquisce una stringa e prova a capire se c'� gi� nel array
        let m = 0;
        let b = 0;
       // this.trovato = false;
        this.playersPerCoach = new Array<string>();
        if (this.playersPerCoach.length === 0) {
            this.playersPerCoach.push(p);
        }
        else {
            for (b = 0; b < this.playersPerCoach.length; b++) {
                m++;
                if (p === this.playersPerCoach[b]) {
                    break;
                }
                else {
                    if (m === this.playersPerCoach.length) {
                       
                     this.playersPerCoach.push(p);
                       
                    }

                }
            }
        }
        console.log('Giocatori del coach ' + this.playersPerCoach);
       


        return true;
    }

    NumberPlayer1(lista: Array<string>): boolean {         // si cerca di una variabile di controlo per players presenti nella lista coach o no 
       // this.trovato = false; 
        if (lista.length != 0) {
            this.trovato++;
        }
        console.log('trovato: ' + this.trovato);
        return true;
    }

    PlayersId(p: number): boolean {                  // numero totale di id 
        let m = 0;
        let b = 0;

        if (this.idList.length === 0) {
            this.idList.push(p);
        }
        else {
            for (b = 0; b < this.idList.length; b++) {
                m++;
                if (p === this.idList[b]) {
                    break;
                }
                else {
                    if (m === this.idList.length) {
                        this.idList.push(p);
                    }

                }
            }
        }
        console.log('Giocatori id ' + this.idList);



        return true;
    }
    IDToInsert(p: Array<number>): boolean {          // prende il max e lo prepara per l'inserimento anche se in questo caso ci pensa il sistema dopo il click per l'inserzione,cmq assai prestante
        let n = 0;
        if (p.length === 0) {
            this.idbest = 1;
        }
        if (p.length !== 0) {
            for (let m = 0; m < p.length; m++) {
                n++;
                if (n === p.length) {
                    this.idbest = p[n - 1];
                    this.idbest++;
                    console.log('ID Insert1: ' + this.idbest);
                   
                }
            }

        }
       
        return true;
    }

   

    getPlayers_Users(p: string): boolean {                 // filtra i players per ridondanza
        let m = 0;
        let b = 0;
      

        if (this.players_users.length === 0) {
            this.players_users.push(p);
        }
        else {
            for (b = 0; b < this.players_users.length; b++) {
                m++;
                if (p === this.players_users[b]) {
                    break;
                }
                else {
                    if (m === this.players_users.length) {
                        this.players_users.push(p);
                    }

                }
            }
        }
        console.log('Giocatori occupati ' + this.players_users); 
         
   

        return true;
    }

  
    getPlayersUsers(p: string): boolean {
        let m = 0;
        let b = 0;
        if (this.playersusers.length === 0) {
            this.playersusers.push(p);
        }
        else {
            for (b = 0; b < this.playersusers.length; b++) {
                m++;
                if (p === this.playersusers[b]) {
                    break;
                }
                else {
                    if (m === this.playersusers.length) {
                        this.playersusers.push(p);
                    }

                }
            }
        }
        console.log('Giocatori inseriti da admin ' + this.playersusers);



        return true;
    }

   

   /* GiocatoriLiberi(): boolean {                                          // diff tra colonne e restituisce i players liberi
       
       
        let flag = false;
        console.log('lunghezza array1 ' + this.playersusers.length);  // admin
        console.log('lunghezza array2 ' + this.players_users.length);  // player
       
        if (this.playersusers.length != 0 && this.players_users.length != 0) {
           
            for ( this.w = 0; this.w < this.playersusers.length; this.w++) {
               // g++;
                for ( this.v = 0; this.v < this.players_users.length; this.v++) {
                   // f++;
                    if ((this.playersusers[this.w] === this.players_users[this.v])) {
                        flag = true;
                       this.v=0;
                    }
                    if (flag) {
                        flag = false;
                        break;
                    }
                    
                }
                if (this.v === this.players_users.length) {
                    this.diffPlayers.push(this.playersusers[this.w]);
                    console.log('models: ' + this.playersusers[this.w] );
                    this.k++;
                    this.v = 0;
                }
            }
        }
        if (this.k === 0) {
            console.log('Non ci sono giocatori liberi sul momento');
        }
        else {
            console.log('Giocatori liberi ' + this.diffPlayers);
        }
        return true;
    }  */


    GiocatoriLiberi(playersusers1: Array<string>, players_users1: Array<string>): boolean {                                          // diff tra colonne e restituisce i players liberi


        let flag = false;
        console.log('lunghezza array1 ' + playersusers1.length);  // admin
        console.log('lunghezza array2 ' + players_users1.length);  // player
       
        this.diffPlayers = new Array<string>();
        if (playersusers1.length != 0 && players_users1.length != 0) {

            for (this.w = 0; this.w < playersusers1.length; this.w++) {
                // g++;
                for (this.v = 0; this.v < players_users1.length; this.v++) {
                    // f++;
                    if ((playersusers1[this.w] === players_users1[this.v])) {
                        flag = true;
                        this.v = 0;
                    }
                    if (flag) {
                        flag = false;
                        break;
                    }

                }
                if (this.v === players_users1.length) {
                    this.diffPlayers.push(playersusers1[this.w]);
                    console.log('models: ' + playersusers1[this.w]);
                    this.k++;
                    this.v = 0;
                }
            }
        }
        if (this.k === 0) {
            console.log('Non ci sono giocatori liberi sul momento');
        }
        else {
            console.log('Giocatori liberi ' + this.diffPlayers);
        }
        return true;
    }  



   /* GiocatoriLiberi(playersusers1: Array<string>, players_users1: Array<string>): boolean {                                          // diff tra colonne e restituisce i players liberi

        let n = 0;
        let m = 0;
        let flag1 = false;
        let flag2 = false;
        console.log('lunghezza array1 ' + playersusers1.length);  // admin
        console.log('lunghezza array2 ' + players_users1.length);  // player
        this.diffPlayers = new Array<string>();
        this.k = 0;
        if (playersusers1.length != 0 && players_users1.length != 0) {

            for (n = 0; n < playersusers1.length; n++) {
               
                for (m = 0; m < players_users1.length; m++) {
                   
                    if ((playersusers1[n] === players_users1[m])) {
                       // flag1 = true;
                        break;
                    }
                   // if (flag1)  break;
                  // flag1 = false;
                    if (m === players_users1.length) {
                        this.diffPlayers.push(playersusers1[n]);
                        console.log('models: ' + playersusers1[n]);
                        this.k++;
                        // m = 0;
                    }  
                    
                }  // end for 1
               
            }   // end for 2
        }
        if (this.k === 0) {
            console.log('Non ci sono giocatori liberi sul momento');
        }
        else {
            console.log('Giocatori liberi ' + this.diffPlayers);
        }
        return true;
    }  */


   /* GiocatoriLiberi(playersusers1: Array<string>, players_users1: Array<string>): boolean {         //  Non serve


        let flag = false;
        console.log('lunghezza array1 ' + playersusers1.length);  // admin
        console.log('lunghezza array2 ' + players_users1.length);  // player

        if (playersusers1.length != 0 && players_users1.length != 0) {

            for (this.w = 0; this.w < playersusers1.length; this.w++) {
                // g++;
                for (this.v = 0; this.v < players_users1.length; this.v++) {
                    // f++;
                    if ((playersusers1[this.w] === players_users1[this.v])) {
                        flag = true;
                        this.v = 0;
                    }
                    if (flag) {
                        flag = false;
                        break;
                    }

                }
                if (this.v === players_users1.length) {
                    this.diffPlayers.push(playersusers1[this.w]);
                    console.log('models: ' + playersusers1[this.w]);
                    this.k++;
                    this.v = 0;
                }
            }
        }
        if (this.k === 0) {
            console.log('Non ci sono giocatori liberi sul momento');
        }
        else {
            console.log('Giocatori liberi ' + this.diffPlayers);
        }
        return true;
    } */
     
   filtraModelli(lista: Array<string>): boolean {         // filtra per� c'� ridondanza nella chiamata
       
        let u = 0;
        this.resultPlayers = new Array<string>();
        if (lista.length != 0) {
            for (let i = 0; i < lista.length; i++) {
                if (i == 0) {
                    this.resultPlayers.push(lista[i]);
                }
                else {
                    if (lista[i] != this.resultPlayers[u]) {
                        this.resultPlayers.push(lista[i]);
                        u++;
                    }
                }
            }
        }

        return true;
    }
   

    filtraPlayersLiberi(p: string): boolean {                 // filtra la ridondanza 
        let m = 0;
        let b = 0;
       

        if (this.filtrare.length === 0) {
            this.filtrare.push(p);
        }
        else {
            for (b = 0; b < this.filtrare.length; b++) {
                m++;
                if (p === this.filtrare[b]) {
                    break;
                }
                else {
                    if (m === this.filtrare.length) {
                        this.filtrare.push(p);
                    }

                }
            }
        }
        return true;
    }

   


    checkDiv(): void {                                       // serve per attivare il bottone di consultazione,quindi abilita alcune finestre in cui le viste ci permettono di usufruire di alcuni servizi
        this.number++;
        this.reste = this.number % 2;
    }
  

    getPlayers() {
        this.goTo();
        this.idcoach = JSON.parse(localStorage.getItem('coachId'));
        this.playerService.getAll().subscribe((players: PlayerDTO[]) => { this.players1 = players; console.log('PlayersCoach' + players) });
        console.log("sono nella get players: " + this.players1);
    }

    getUsers() {
        
        this.userService.getAll().subscribe(users => this.users = users);
       
    }

    OnCreate(value1, value2, value3, value4, value5, value6, value7, value8): void {
        this.goTo();
       
        if (this.si_puo) {
            this.playertoinsert.id = value1;
            this.playertoinsert.idPlayer = value2;
            this.playertoinsert.idCoach = value3;
            this.playertoinsert.playername = value4;
            this.playertoinsert.playertype = value5;
            this.playertoinsert.age = value6;
            this.playertoinsert.gamep = value7;
            this.playertoinsert.score = value8;
            this.playerService.insert(this.playertoinsert).subscribe(() => this.getPlayers());
            this.m1 = true;
            this.mess = "Inserimento del player nella sua squadra avvenuto con successo !!! ";
        }
        if (!(this.si_puo) && !(this.create2)) {
            this.m1 = true;
            this.mess = "Il player non esiste nel sistema oppure potrebbe essere gia impegnato da un coach !!! ";
        }
        if (!(this.si_puo) && (this.create2)) {
            this.m1 = true;
            this.mess = "Puo creare adesso il player inserito nel campo per la tua squadra !!! ";
        }

    }
    OnUpdate(value1x, value2x, value3x, value4x, value5x, value6x, value7x, value8x) {
        this.goTo();
        this.playertoinsert = new PlayerDTO();
        this.playertoinsert.id = value1x;
        this.playertoinsert.idPlayer = value2x;
        this.playertoinsert.idCoach = value3x;
        this.playertoinsert.playername = value4x;
        this.playertoinsert.playertype = value5x;
        this.playertoinsert.age = value6x;
        this.playertoinsert.gamep = value7x;
        this.playertoinsert.score = value8x;
        this.playerService.update(this.playertoinsert).subscribe(() => this.getPlayers());
    }

    onDelete(): void {

        if (this.clique) {
            this.p++;
            this.resto = this.p % 2;
            if (this.resto === 1) {
                this.create1 = true;
                this.create2 = true;
            }
            else {
                this.create1 = false;
                this.create2 = false;
                this.clique = false;
               
            }
        }
      
    }


  
    OnDelete(value) {
        this.goTo();
        this.clique = true;
        this.playerService.delete(value).subscribe(() => this.getPlayers());
        this.m1 = true;
        this.mess = "Cancellazione del player della sua squadra la tua squadra !!! ";
       
    }

    OnClear(): void {                      // c'� da ottimizzare questo servizio
       // this.playerdto = new PlayerDTO(); 
        this.playerdto.id = 0;
        this.playerdto.idCoach = JSON.parse(localStorage.getItem('coachId'));
        this.playerdto.idPlayer = 0;
        this.playerdto.playername = "Name";
        this.playerdto.age = 0;
        this.playerdto.gamep = 0;
        this.playerdto.score = 0;

      
      
    } 

   

    get coachPlayer(): boolean {
        this.var1 = true;
        return this.var1;
    }
    
     ctlrMet(): boolean {
         this.i++;
         return true;
     }
    Ondo(): void {
        this.var1 = true;
        this.getUsers();
      
        
    }

   

    getPlayersCoach(): void {
         this.idcoach = JSON.parse(localStorage.getItem('coachId'));
        this.playerService.getAll().subscribe((players) => { this.players1 = players; console.log('PlayersCoach' + players) });

      //  if (this.players1.length != 0) {
            this.message = 1;
          /*  for (this.i = 0; this.i < this.players1.length; this.i++) {
                if (this.players1[this.i].id === JSON.parse(localStorage.getItem('coachId'))) {
                    this.playersCoach[this.idcoach].id = this.players1[this.i].id;
                    this.playersCoach[this.idcoach].idCoach = this.players1[this.i].idCoach;
                    this.playersCoach[this.idcoach].playername = this.players1[this.i].playername;
                    this.playersCoach[this.idcoach].playertype = this.players1[this.i].playertype;
                    this.playersCoach[this.idcoach].age = this.players1[this.i].age;
                    this.playersCoach[this.idcoach].gamep = this.players1[this.i].gamep;
                    this.playersCoach[this.idcoach].score = this.players1[this.i].score;

                    this.idcoach++;

                }
               
            } */
      //  }  // end if null
     /*  else {
            this.message = 2;
        } */
        this.i = 0;

        for (let playerdtow of this.players1) {

           
            if (playerdtow.id == this.idcoach) {
                console.log('istanza lista player' + this.i);
               // this.playersCoach[this.i].id = playerdtow.id;
                this.i++;
            } 

        }
    } 
   

}
