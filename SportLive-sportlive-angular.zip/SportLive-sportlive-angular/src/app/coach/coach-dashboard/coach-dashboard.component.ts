import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coach-dashboard',
  templateUrl: './coach-dashboard.component.html',
  styleUrls: ['./coach-dashboard.component.css']
})
export class CoachDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
